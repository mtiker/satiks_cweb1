using System.Globalization;
using System.IdentityModel.Tokens.Jwt;
using System.Text;
using App.BLL.Contracts;
using App.BLL.Services;
using App.DAL.Contracts;
using App.DAL.EF;
using App.DAL.EF.Seeding;
using App.Domain.Identity;
using Asp.Versioning;
using Asp.Versioning.ApiExplorer;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.DataProtection;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Localization;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Diagnostics;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using Npgsql;
using Swashbuckle.AspNetCore.SwaggerGen;
using WebApp;

// Fix: allow DateTime.Kind=Unspecified to be written to PostgreSQL timestamptz
AppContext.SetSwitch("Npgsql.EnableLegacyTimestampBehavior", true);

var builder = WebApplication.CreateBuilder(args);

var connectionString = builder.Configuration.GetConnectionString("DefaultConnection")
    ?? throw new InvalidOperationException("DefaultConnection not found.");

builder.Services.AddDbContext<AppDbContext>(options =>
{
    options.UseNpgsql(connectionString,
        o => o.UseQuerySplittingBehavior(QuerySplittingBehavior.SplitQuery))
        .ConfigureWarnings(w => w.Throw(RelationalEventId.MultipleCollectionIncludeWarning))
        .UseQueryTrackingBehavior(QueryTrackingBehavior.NoTrackingWithIdentityResolution);
    if (builder.Environment.IsDevelopment())
        options.EnableDetailedErrors().EnableSensitiveDataLogging();
});

builder.Services.AddDatabaseDeveloperPageExceptionFilter();
builder.Services.AddDataProtection().PersistKeysToDbContext<AppDbContext>();

builder.Services.AddIdentity<AppUser, AppRole>(o => o.SignIn.RequireConfirmedAccount = false)
    .AddDefaultUI()
    .AddEntityFrameworkStores<AppDbContext>()
    .AddDefaultTokenProviders();

var jwtKey = builder.Configuration["JWT:Key"]
    ?? throw new InvalidOperationException("JWT:Key is not configured.");
var jwtIssuer = builder.Configuration["JWT:Issuer"]
    ?? throw new InvalidOperationException("JWT:Issuer is not configured.");
var jwtAudience = builder.Configuration["JWT:Audience"]
    ?? throw new InvalidOperationException("JWT:Audience is not configured.");

JwtSecurityTokenHandler.DefaultInboundClaimTypeMap.Clear();
builder.Services
    .AddAuthentication()
    .AddCookie(o => o.SlidingExpiration = true)
    .AddJwtBearer(cfg =>
    {
        cfg.RequireHttpsMetadata = false;
        cfg.SaveToken = true;
        cfg.TokenValidationParameters = new TokenValidationParameters
        {
            ValidIssuer = jwtIssuer,
            ValidAudience = jwtAudience,
            IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwtKey)),
            ClockSkew = TimeSpan.Zero
        };
    });

builder.Services.AddScoped<IAppUOW, AppUOW>();

builder.Services.AddScoped<ILaboratoryService, LaboratoryService>();
builder.Services.AddScoped<IDepartmentService, DepartmentService>();
builder.Services.AddScoped<ILocationService, LocationService>();
builder.Services.AddScoped<IEquipmentCategoryService, EquipmentCategoryService>();
builder.Services.AddScoped<IManufacturerService, ManufacturerService>();
builder.Services.AddScoped<IMaintenanceRecordService, MaintenanceRecordService>();
builder.Services.AddScoped<ICalibrationRecordService, CalibrationRecordService>();
builder.Services.AddScoped<ITrainingCertificationService, TrainingCertificationService>();
builder.Services.AddScoped<IEquipmentService, EquipmentService>();
builder.Services.AddScoped<IBookingService, BookingService>();

var supportedCultures = builder.Configuration
    .GetSection("SupportedCultures").GetChildren()
    .Select(x => new CultureInfo(x.Value!)).ToArray();

builder.Services.AddLocalization(opts => opts.ResourcesPath = "");

builder.Services.Configure<RequestLocalizationOptions>(opts =>
{
    var supported = new[] { "et-EE", "en-GB" };
    opts.SetDefaultCulture("et-EE")
        .AddSupportedCultures(supported)
        .AddSupportedUICultures(supported);

    opts.RequestCultureProviders.Insert(
        0, new Microsoft.AspNetCore.Localization.CookieRequestCultureProvider());
});

builder.Services.AddCors(options =>
    options.AddPolicy("CorsAllowAll", policy => policy
        .AllowAnyOrigin().AllowAnyHeader().AllowAnyMethod()
        .WithExposedHeaders("X-Version")));

builder.Services.AddApiVersioning(options =>
{
    options.ReportApiVersions = true;
    options.DefaultApiVersion = new ApiVersion(1, 0);
}).AddApiExplorer(options =>
{
    options.GroupNameFormat = "'v'VVV";
    options.SubstituteApiVersionInUrl = true;
});

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddTransient<IConfigureOptions<SwaggerGenOptions>, ConfigureSwaggerOptions>();
builder.Services.AddSwaggerGen();

builder.Services.AddControllersWithViews()
    .AddViewLocalization()
    .AddDataAnnotationsLocalization(o =>
        o.DataAnnotationLocalizerProvider = (_, factory) =>
            factory.Create(typeof(App.Resources.Common)));

builder.Services.ConfigureApplicationCookie(options =>
{
    options.LoginPath = "/User/Account/Login";
    options.AccessDeniedPath = "/Home/AccessDenied";
});

var app = builder.Build();

SetupAppData(app, app.Environment, app.Configuration);

if (app.Environment.IsDevelopment())
    app.UseMigrationsEndPoint();
else
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseCors("CorsAllowAll");
app.UseRouting();

app.UseRequestLocalization(
    app.Services.GetRequiredService<Microsoft.Extensions.Options.IOptions<RequestLocalizationOptions>>().Value);

app.UseAuthentication();
app.UseAuthorization();

app.UseSwagger();
app.UseSwaggerUI(options =>
{
    foreach (var desc in app.Services.GetRequiredService<IApiVersionDescriptionProvider>().ApiVersionDescriptions)
        options.SwaggerEndpoint($"/swagger/{desc.GroupName}/swagger.json", desc.GroupName.ToUpperInvariant());
});

app.MapStaticAssets();
app.MapAreaControllerRoute(
    name: "Admin",
    areaName: "Admin",
    pattern: "Admin/{controller=Home}/{action=Index}/{id?}");
app.MapAreaControllerRoute(
    name: "Technician",
    areaName: "Technician",
    pattern: "Technician/{controller=TechnicianHome}/{action=Index}/{id?}");
app.MapAreaControllerRoute(
    name: "User",
    areaName: "User",
    pattern: "User/{controller=Account}/{action=Login}/{id?}");
app.MapControllerRoute("areas", "{area:exists}/{controller=Home}/{action=Index}/{id?}").WithStaticAssets();
app.MapControllerRoute("default", "{controller=Home}/{action=Index}/{id?}").WithStaticAssets();
app.MapRazorPages().WithStaticAssets();

app.Run();
return;

static void SetupAppData(IApplicationBuilder app, IWebHostEnvironment env, IConfiguration cfg)
{
    using var scope = app.ApplicationServices.GetRequiredService<IServiceScopeFactory>().CreateScope();
    var logger = scope.ServiceProvider.GetRequiredService<ILogger<IApplicationBuilder>>();
    using var ctx = scope.ServiceProvider.GetRequiredService<AppDbContext>();

    var um = scope.ServiceProvider.GetRequiredService<UserManager<AppUser>>();
    var rm = scope.ServiceProvider.GetRequiredService<RoleManager<AppRole>>();

    WaitDbConnection(ctx, logger);

    if (cfg.GetValue<bool>("DataInitialization:DropDatabase"))    { logger.LogWarning("DropDatabase");        AppDataInit.DeleteDatabase(ctx); }
    if (cfg.GetValue<bool>("DataInitialization:MigrateDatabase")) { logger.LogInformation("MigrateDatabase"); AppDataInit.MigrateDatabase(ctx); }
    if (cfg.GetValue<bool>("DataInitialization:SeedIdentity"))    { logger.LogInformation("SeedIdentity");    AppDataInit.SeedIdentity(um, rm); }
    if (cfg.GetValue<bool>("DataInitialization:SeedData"))        { logger.LogInformation("SeedData");        AppDataInit.SeedAppData(ctx); }
}

static void WaitDbConnection(AppDbContext ctx, ILogger<IApplicationBuilder> logger)
{
    while (true)
    {
        try { ctx.Database.OpenConnection(); ctx.Database.CloseConnection(); return; }
        catch (NpgsqlException e)
        {
            logger.LogWarning("DB not ready: {Msg}", e.Message);
            if (e.Message.Contains("does not exist")) return;
            Thread.Sleep(1000);
        }
    }
}

public partial class Program { }