using System.ComponentModel.DataAnnotations;

namespace WebApp.ViewModels.Technician;

public class MaintenanceEditViewModel
{
    public Guid Id { get; set; }

    public string EquipmentName { get; set; } = string.Empty;

    public string Description { get; set; } = string.Empty;

    [MaxLength(1024)]
    public string? Resolution { get; set; }

    public DateTime? CompletedDate { get; set; }

    [Range(0, double.MaxValue)]
    public decimal? Cost { get; set; }

    public bool IsScheduled { get; set; }
}
