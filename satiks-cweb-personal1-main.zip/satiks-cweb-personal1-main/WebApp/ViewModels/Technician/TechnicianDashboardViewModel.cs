using App.DTO.v1;

namespace WebApp.ViewModels.Technician;

public class TechnicianDashboardViewModel
{
    public int ScheduledMaintenanceCount { get; set; }
    public int OverdueCalibrationCount { get; set; }
    public IEnumerable<MaintenanceRecordDto> RecentMaintenance { get; set; } = [];
    public IEnumerable<CalibrationRecordDto> RecentCalibrations { get; set; } = [];
}
