using System.ComponentModel.DataAnnotations;

namespace WebApp.ViewModels.Technician;

public class CalibrationEditViewModel
{
    public Guid Id { get; set; }

    public string EquipmentName { get; set; } = string.Empty;

    [MaxLength(128)]
    public string? CertificateNumber { get; set; }

    public bool Passed { get; set; }

    [MaxLength(1024)]
    public string? Notes { get; set; }

    [Required]
    public DateTime NextCalibrationDue { get; set; }
}
