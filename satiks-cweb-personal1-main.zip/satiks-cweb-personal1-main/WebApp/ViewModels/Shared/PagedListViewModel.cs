using Microsoft.AspNetCore.Mvc.Rendering;

namespace WebApp.ViewModels.Shared;

public abstract class PagedListViewModel
{
    public int Page { get; set; } = 1;
    public int PageSize { get; set; } = 20;
    public int TotalCount { get; set; }
    public FilterState FilterState { get; set; } = new();

    public int TotalPages => (int)Math.Ceiling(TotalCount / (double)PageSize);
    public bool HasPreviousPage => Page > 1;
    public bool HasNextPage => Page < TotalPages;
}

public abstract class PagedListViewModel<T> : PagedListViewModel
{
    public IReadOnlyList<T> Items { get; set; } = [];
}