namespace WebApp.ViewModels.Shared;

public class DataTableConfig
{
    public required List<string> Columns { get; init; }
    public bool ShowActions { get; init; } = true;
    public string? EmptyMessage { get; init; }
}

public class DataTableViewModel
{
    public required string RowsPartialName { get; init; }
    public required object RowsModel { get; init; }
    public required DataTableConfig Config { get; init; }
    public bool IsEmpty { get; init; }
}