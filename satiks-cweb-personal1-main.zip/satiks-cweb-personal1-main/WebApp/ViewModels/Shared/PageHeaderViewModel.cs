namespace WebApp.ViewModels.Shared;

public record PageHeaderViewModel(
    string Title,
    string? ActionLabel = null,
    string? ActionUrl = null
);