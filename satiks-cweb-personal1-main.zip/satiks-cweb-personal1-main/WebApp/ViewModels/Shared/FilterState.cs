using Microsoft.AspNetCore.Mvc.Rendering;

namespace WebApp.ViewModels.Shared;

public class FilterState
{
    public string? SearchTerm { get; set; }
    public List<FilterDefinition> Definitions { get; init; } = [];
    public Dictionary<string, string?> CurrentValues { get; set; } = [];
}

public record FilterDefinition(
    string Key,
    string Label,
    List<SelectListItem> Options
);