using System.ComponentModel.DataAnnotations;

namespace App.DTO.v1;

public class MaintenanceRecordDto
{
    public Guid Id { get; set; }

    [Required]
    public DateTime ScheduledDate { get; set; }

    public DateTime? CompletedDate { get; set; }

    [Required]
    [MaxLength(1024)]
    public string Description { get; set; } = default!;

    [MaxLength(1024)]
    public string? Resolution { get; set; }

    public decimal? Cost { get; set; }

    public bool IsScheduled { get; set; }

    public Guid EquipmentId { get; set; }
    public string? EquipmentName { get; set; }

    public Guid? PerformedByUserId { get; set; }
    public string? PerformedByUserName { get; set; }
}

public class MaintenanceRecordCreateDto
{
    [Required]
    public DateTime ScheduledDate { get; set; }

    public DateTime? CompletedDate { get; set; }

    [Required]
    [MaxLength(1024)]
    public string Description { get; set; } = default!;

    [MaxLength(1024)]
    public string? Resolution { get; set; }

    public decimal? Cost { get; set; }

    public bool IsScheduled { get; set; } = true;

    [Required]
    public Guid EquipmentId { get; set; }

    public Guid? PerformedByUserId { get; set; }
}

public class MaintenanceRecordUpdateDto : MaintenanceRecordCreateDto
{
    public Guid Id { get; set; }
}
