using System.ComponentModel.DataAnnotations;

namespace App.DTO.v1;

public class LocationDto
{
    public Guid Id { get; set; }

    /// <summary>Mapped from LangStr via culture resolution.</summary>
    public string BuildingName { get; set; } = default!;

    public string? BuildingNameEn { get; set; }
    public string? BuildingNameEt { get; set; }

    [MaxLength(16)]
    public string? Floor { get; set; }

    [MaxLength(16)]
    public string? RoomNumber { get; set; }

    [MaxLength(256)]
    public string? Address { get; set; }
}

public class LocationCreateDto
{
    [Required]
    [MaxLength(256)]
    /// <summary>English building name. Stored as the default culture translation.</summary>
    public string BuildingName { get; set; } = default!;

    [MaxLength(256)]
    /// <summary>Optional Estonian translation. Stored as the 'et' culture slot.</summary>
    public string? BuildingNameEt { get; set; }

    [MaxLength(16)]
    public string? Floor { get; set; }

    [MaxLength(16)]
    public string? RoomNumber { get; set; }

    [MaxLength(256)]
    public string? Address { get; set; }
}

public class LocationUpdateDto : LocationCreateDto
{
    public Guid Id { get; set; }
}