using System.ComponentModel.DataAnnotations;

namespace App.DTO.v1;

public class ManufacturerDto
{
    public Guid Id { get; set; }

    public string Name { get; set; } = default!;
    public string? NameEn { get; set; }
    public string? NameEt { get; set; }

    [MaxLength(64)]
    public string? Country { get; set; }

    [MaxLength(256)]
    public string? Website { get; set; }

    [MaxLength(64)]
    public string? SupportPhone { get; set; }

    [MaxLength(256)]
    public string? SupportEmail { get; set; }
}

public class ManufacturerCreateDto
{
    [Required]
    [MaxLength(256)]
    public string Name { get; set; } = default!;

    [MaxLength(256)]
    public string? NameEt { get; set; }

    [MaxLength(64)]
    public string? Country { get; set; }

    [MaxLength(256)]
    public string? Website { get; set; }

    [MaxLength(64)]
    public string? SupportPhone { get; set; }

    [MaxLength(256)]
    public string? SupportEmail { get; set; }
}

public class ManufacturerUpdateDto : ManufacturerCreateDto
{
    public Guid Id { get; set; }
}
