using System.ComponentModel.DataAnnotations;

namespace App.DTO.v1;

public class TrainingCertificationDto
{
    public Guid Id { get; set; }

    [Required]
    public DateTime CertifiedDate { get; set; }

    public DateTime? ExpiryDate { get; set; }

    [MaxLength(128)]
    public string? CertificateReference { get; set; }

    /// <summary>Valid values: Pending, Approved, Rejected, Revoked, Expired</summary>
    [Required]
    public string Status { get; set; } = default!;

    public Guid AppUserId { get; set; }
    public string? AppUserFullName { get; set; }

    public Guid EquipmentCategoryId { get; set; }
    public string? EquipmentCategoryName { get; set; }

    public Guid? ValidatedByUserId { get; set; }
    public string? ValidatedByUserName { get; set; }

    public DateTime? ValidatedAt { get; set; }

    [MaxLength(1024)]
    public string? ValidationComment { get; set; }
}

public class TrainingCertificationCreateDto
{
    [Required]
    public DateTime CertifiedDate { get; set; }

    public DateTime? ExpiryDate { get; set; }

    [MaxLength(128)]
    public string? CertificateReference { get; set; }

    [Required]
    public Guid EquipmentCategoryId { get; set; }

    /// <summary>Status is NOT included. Always set to Pending server-side on creation.</summary>
    /// <summary>AppUserId is NOT included. Always taken from the authenticated user's identity claim.</summary>
}

public class TrainingCertificationUserUpdateDto
{
    [Required]
    public Guid Id { get; set; }

    [Required]
    public DateTime CertifiedDate { get; set; }

    public DateTime? ExpiryDate { get; set; }

    [MaxLength(128)]
    public string? CertificateReference { get; set; }

    /// <summary>Status is NOT included. Users cannot change their own status.</summary>
}

public class TrainingCertificationAdminUpdateDto
{
    [Required]
    public Guid Id { get; set; }

    /// <summary>Valid values: Approved, Rejected, Revoked (Pending and Expired are set server-side)</summary>
    [Required]
    public string Status { get; set; } = default!;

    [MaxLength(1024)]
    public string? ValidationComment { get; set; }

    /// <summary>ValidatedByUserId and ValidatedAt are set server-side from the authenticated admin's identity and DateTime.UtcNow — never accepted from the client.</summary>
}
