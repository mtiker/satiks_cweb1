using System.ComponentModel.DataAnnotations;

namespace App.DTO.v1;

public class LaboratoryDto
{
    public Guid Id { get; set; }

    public string Name { get; set; } = default!;
    public string? NameEn { get; set; }
    public string? NameEt { get; set; }

    public string? Description { get; set; }
    public string? DescriptionEn { get; set; }
    public string? DescriptionEt { get; set; }

    public int? MaxOccupancy { get; set; }

    public Guid DepartmentId { get; set; }
    public string? DepartmentName { get; set; }

    public Guid LocationId { get; set; }
    public string? LocationBuildingName { get; set; }

    /// <summary>Read-only. Denormalized count of equipment. Never included in write DTOs.</summary>
    public int EquipmentCount { get; set; }
}

public class LaboratoryCreateDto
{
    [Required]
    [MaxLength(256)]
    public string Name { get; set; } = default!;

    [MaxLength(256)]
    public string? NameEt { get; set; }

    [MaxLength(512)]
    public string? Description { get; set; }

    [MaxLength(512)]
    public string? DescriptionEt { get; set; }

    public int? MaxOccupancy { get; set; }

    [Required]
    public Guid DepartmentId { get; set; }

    [Required]
    public Guid LocationId { get; set; }
}

public class LaboratoryUpdateDto : LaboratoryCreateDto
{
    public Guid Id { get; set; }
}
